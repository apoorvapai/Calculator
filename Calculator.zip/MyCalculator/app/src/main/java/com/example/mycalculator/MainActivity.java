package com.example.mycalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView resulttv,solutiontv;
    MaterialButton buttonc,buttonbrackopen,buttonbrackclose;
    MaterialButton buttondivide,buttonmultiply,buttonadd,buttonsub,buttonequals,button0,button1;
    MaterialButton button2,button3,button4,button5,button6,button7,button8,button9,buttonac,buttondot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //buttonc=findViewById(R.id.button_c);
        resulttv=findViewById(R.id.result_tv);
        solutiontv=findViewById(R.id.solution_tv);
        /*buttonbrackclose=findViewById(R.id.button_close_button);
        buttonbrackopen=findViewById(R.id.button_open_bracket);
        buttondivide=findViewById(R.id.button_divide);
        buttonmultiply=findViewById(R.id.button_multiply);
        buttonadd=findViewById(R.id.button_add);
        buttonsub=findViewById(R.id.button_sub);
        buttonequals=findViewById(R.id.button_equal);
        button0=findViewById(R.id.button_0);
        button1=findViewById(R.id.button_1);
        button2=findViewById(R.id.button_2);
        button3=findViewById(R.id.button_3);
        button4=findViewById(R.id.button_4);
        button5=findViewById(R.id.button_5);
        button6=findViewById(R.id.button_6);
        button7=findViewById(R.id.button_7);
        button8=findViewById(R.id.button_8);
        button9=findViewById(R.id.button_9);
        buttonac=findViewById(R.id.button_ac);
        buttondot=findViewById(R.id.button_dot);*/

        assignId(buttonc,R.id.button_c);
        assignId(buttonbrackclose,R.id.button_close_button);
        assignId(buttonbrackopen,R.id.button_open_bracket);
        assignId(buttondivide,R.id.button_divide);
        assignId(buttonmultiply,R.id.button_multiply);
        assignId(buttonadd,R.id.button_add);
        assignId(buttonsub,R.id.button_sub);
        assignId(buttonequals,R.id.button_equal);
        assignId(buttonac,R.id.button_ac);
        assignId(buttondot,R.id.button_dot);
        assignId(button0,R.id.button_0);
        assignId(button1,R.id.button_1);
        assignId(button2,R.id.button_2);
        assignId(button3,R.id.button_3);
        assignId(button4,R.id.button_4);
        assignId(button5,R.id.button_5);
        assignId(button6,R.id.button_6);
        assignId(button7,R.id.button_7);
        assignId(button8,R.id.button_8);
        assignId(button9,R.id.button_9);



    }

    private void assignId(MaterialButton btn, int id) {
        btn=findViewById(id);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        MaterialButton button=(MaterialButton) view;
        String buttontext=button.getText().toString();
        String datatocalculate=solutiontv.getText().toString();

        if(buttontext.equals("AC")){
            solutiontv.setText("");
            resulttv.setText("0");
            return;
        }
        if(buttontext.equals("=")){
            solutiontv.setText(resulttv.getText());
            return;
        }
        if(buttontext.equals("C")){
            if(datatocalculate.length()>1) {
                datatocalculate = datatocalculate.substring(0, datatocalculate.length() - 1);
            }
            else if(datatocalculate.length()<=1) {
                solutiontv.setText("");
                resulttv.setText("0");
                return;
            }
        }
        else
        {
            datatocalculate=datatocalculate+buttontext;

        }
        solutiontv.setText(datatocalculate);

        String finalresult=getresult(datatocalculate);
        if(!finalresult.equals("err")){
            resulttv.setText(finalresult);
        }

    }

    String getresult(String data){
        try{
            Context context=Context.enter();
            context.setOptimizationLevel(-1);
            Scriptable scriptable=context.initStandardObjects();
            String finalresult=context.evaluateString(scriptable,data,"Javascript",1,null).toString();
            if(finalresult.endsWith(".0")){
                finalresult=finalresult.replace(".0","");
            }
            return finalresult;
        }catch(Exception e){
            return "err";
        }
    }
}